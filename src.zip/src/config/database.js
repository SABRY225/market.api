const { Sequelize } = require('sequelize');
const dotenv = require('dotenv');

dotenv.config();

const sequelize = new Sequelize(
  process.env.DB_NAME ,     // اسم الداتابيز
  process.env.DB_USER,        // اليوزر
  process.env.DB_PASS ,       // الباسورد
  {
    host: process.env.DB_HOST || '127.0.0.1',
    port: Number(process.env.DB_PORT) || 3306,
    dialect: 'mysql',
    logging: false,
  }
);

module.exports = { sequelize };